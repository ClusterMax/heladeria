
package Logica;

public class BebidaAlcoholica {
    private String gradoAlcohol;
    private String marca;
    private CalidadBebidas calidad;

    public BebidaAlcoholica(String gradoAlcohol, String marca, CalidadBebidas calidad) {
        this.gradoAlcohol = gradoAlcohol;
        this.marca = marca;
        this.calidad = calidad;
    }

    public BebidaAlcoholica() {
    }

    
    public String getGradoAlcohol() {
        return gradoAlcohol;
    }

    
    public void setGradoAlcohol(String gradoAlcohol) {
        this.gradoAlcohol = gradoAlcohol;
    }

   
    public String getMarca() {
        return marca;
    }

    
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public CalidadBebidas getCalidad() {
        return calidad;
    }

   
    public void setCalidad(CalidadBebidas calidad) {
        this.calidad = calidad;
    }
    
    
    
}
