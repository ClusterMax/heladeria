package Logica;


public class moneyException extends Exception{
    public moneyException(String mensaje){
        super(mensaje);
    }
}
