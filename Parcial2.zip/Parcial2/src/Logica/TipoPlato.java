
package Logica;


public enum TipoPlato {
    Bebida("Bebida"),
    ComidaRapida("ComidaRapida");
    
    
    
    private String tipo;
    
    private TipoPlato(String tip){
     this.tipo=tip;
    }
    
    public String getTipo(){
        return this.tipo;
    }
    
    public void setTipo(String tip){
        tipo=tip;
    }
    
    
    
}
