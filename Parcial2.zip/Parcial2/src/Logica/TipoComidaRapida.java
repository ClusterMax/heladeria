
package Logica;


public enum TipoComidaRapida {
    Perros("Perro"),
    Salchipapas("Salchipapa"),
    Empanadas("Empanada");
    
    
    
    private String tipo;
    
    private TipoComidaRapida(String tip){
     this.tipo=tip;
    }
    
    public String getTipo(){
        return this.tipo;
    }
    
    public void setTipo(String tip){
        tipo=tip;
    }
    
}
