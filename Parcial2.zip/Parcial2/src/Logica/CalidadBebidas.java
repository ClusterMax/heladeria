
package Logica;


public enum CalidadBebidas {
    //Aqui van las bebidas fermentadas o no fermentadas
    Fermentada("Fermentada"),
    NoFermentada("NoFermentada");
    
    
    
    private String tipo;
    
    private CalidadBebidas(String tip){
     this.tipo=tip;
    }
    
     public String getTipo(){
        return this.tipo;
    }
    
    public void setTipo(String tip){
        tipo=tip;
    }
}
