
package Logica;


public class BebidaNoAlcoholica {
    private String ingredientes;
    private String temperatura;
    private String marca;

    public BebidaNoAlcoholica(String ingredientes, String temperatura, String marca) {
        this.ingredientes = ingredientes;
        this.temperatura = temperatura;
        this.marca = marca;
    }

    public BebidaNoAlcoholica() {
    }

    
    public String getIngredientes() {
        return ingredientes;
    }

    
    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

   
    public String getTemperatura() {
        return temperatura;
    }

    
    public void setTemperatura(String temperatura) {
        this.temperatura = temperatura;
    }

    
    public String getMarca() {
        return marca;
    }

    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
    
    
}
