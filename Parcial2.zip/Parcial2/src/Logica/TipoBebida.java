/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

/**
 *
 * @author usuario
 */
public enum TipoBebida {
    Alcoholica("Alcoholica"),
    NoAlcoholica("NoAlcoholica");
    
    
    
    private String tipo;
    
    private TipoBebida(String tip){
     this.tipo=tip;
    }
    
     public String getTipo(){
        return this.tipo;
    }
    
    public void setTipo(String tip){
        tipo=tip;
    }
    
}
