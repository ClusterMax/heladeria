
package Logica;

public class Plato {
    private String nombre;
    private double precio;
    private double factura;
    private BebidaAlcoholica bebidaAlcoholica;
    private BebidaNoAlcoholica bebidaNoAlcoholica;
    private TipoPlato tipoPlato;
    private TipoComidaRapida tipoComida;
    private TipoBebida tipoBebida;

    public Plato(String nombre, double precio, BebidaAlcoholica bebidaAlcoholica, TipoPlato tipoPlato, TipoBebida tipoBebida) {
        this.nombre = nombre;
        this.precio = precio;
        this.bebidaAlcoholica = bebidaAlcoholica;
        this.tipoPlato = tipoPlato;
        this.tipoBebida = tipoBebida;
    }

    public Plato(String nombre, double precio, BebidaNoAlcoholica bebidaNoAlcoholica, TipoPlato tipoPlato, TipoBebida tipoBebida) {
        this.nombre = nombre;
        this.precio = precio;
        this.bebidaNoAlcoholica = bebidaNoAlcoholica;
        this.tipoPlato = tipoPlato;
        this.tipoBebida = tipoBebida;
    }

    public Plato(String nombre, double precio, TipoPlato tipoPlato, TipoComidaRapida tipoComida) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipoPlato = tipoPlato;
        this.tipoComida = tipoComida;
    }

    
    public String getNombre() {
        return nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    public double getPrecio() {
        return precio;
    }

   
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    
    public double getFactura() {
        return factura;
    }

    public void setFactura(double factura) {
        this.factura = factura;
    }

    
    public BebidaAlcoholica getBebidaAlcoholica() {
        return bebidaAlcoholica;
    }

   
    public void setBebidaAlcoholica(BebidaAlcoholica bebidaAlcoholica) {
        this.bebidaAlcoholica = bebidaAlcoholica;
    }

    
    public BebidaNoAlcoholica getBebidaNoAlcoholica() {
        return bebidaNoAlcoholica;
    }

   
    public void setBebidaNoAlcoholica(BebidaNoAlcoholica bebidaNoAlcoholica) {
        this.bebidaNoAlcoholica = bebidaNoAlcoholica;
    }

   
    public TipoPlato getTipoPlato() {
        return tipoPlato;
    }

    
    public void setTipoPlato(TipoPlato tipoPlato) {
        this.tipoPlato = tipoPlato;
    }

    
    public TipoComidaRapida getTipoComida() {
        return tipoComida;
    }

   
    public void setTipoComida(TipoComidaRapida tipoComida) {
        this.tipoComida = tipoComida;
    }

    
    public TipoBebida getTipoBebida() {
        return tipoBebida;
    }

    
    public void setTipoBebida(TipoBebida tipoBebida) {
        this.tipoBebida = tipoBebida;
    }
    
    
    
    
    
    

   
    
    
    
}
