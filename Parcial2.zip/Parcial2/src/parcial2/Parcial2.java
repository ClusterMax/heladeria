
package parcial2;

import Logica.FRM;


public class Parcial2 {

    public static void main(String[] args) {
        FRM frm = new FRM();
        frm.setVisible(true);
    }
    
}
